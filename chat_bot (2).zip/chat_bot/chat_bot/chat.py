import os
import logging
from heyoo import WhatsApp
from dotenv import load_dotenv
from langchain_openai import OpenAI
import openai
import time
# from llama_index import SimpleDirectoryReader
from llama_index.core import GPTVectorStoreIndex, ServiceContext,SimpleDirectoryReader,Settings
from typing import Iterator
# import llama_index 

# from llama_index.readers.file import BaseReader

import sys
print(sys.path) 

from flask import (
  Flask,
  request, 
  make_response,
)

load_dotenv()  # Load environment variables from .env file
openai_key = os.getenv('OPENAI_API_KEY')
phone_number_id = os.getenv('PHONE_NUMBER_ID')
whatsapp_token = os.getenv('WHATSAPP_TOKEN')
print('=-=-=-=-=-=-=-=-=-=-=-=',whatsapp_token)

'''
Creates a WhatsApp object with the retrieved tokens,
allowing the app to send messages via WhatsApp.'''

messenger = WhatsApp(
  os.environ["WHATSAPP_TOKEN"],
  phone_number_id=os.environ["PHONE_NUMBER_ID"] )

#   Initializes a Flask app to handle web requests.
app = Flask(__name__)

VERIFY_TOKEN = "30cca545-3838-48b2-80a7-9e43b1ae8cf5"

# Sets up logging to track events and messages, which helps in debugging.
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
# Initializes an OpenAI object with specific model settings to interact with OpenAI's API.
os.environ['OPENAI_API_KEY'] = openai_key
print('-------------------------')

# Add predictor
llm_predictor = OpenAI(temperature=0, model_name="text-embedding-ada-002")

# llm_predictor = OpenAI(temperature=0, model_name="text-davinci-003")
print('>>>>>>>>>>>>>>>>>:::::::>>>>>>>>>>>>>>>>>>>>')


# Load documents

documents = SimpleDirectoryReader("documents").load_data()
print("llm_predictor:", llm_predictor)
print('>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>')

Settings.llm = llm_predictor
index = GPTVectorStoreIndex.from_documents(documents)

# Create service context and index
# service_context = ServiceContext.from_defaults(llm_predictor=llm_predictor)


# index = GPTVectorStoreIndex.from_documents(documents, service_context=service_context)
print('>>>>>>>>>>>>>>>>>>>>++++++++>>>>>>>>>>>>>>>>>')

# Save index
index.save_to_disk("index.json")

# Load saved index
index = GPTVectorStoreIndex.load_from_disk("index.json")
print("-----end------")
def get_embeddings_with_retries(text, retries=5):
    for i in range(retries):
        try:
            response = openai.Embedding.create(input=text, model="text-embedding-ada-002")
            return response
        except openai.error.RateLimitError:
            if i < retries - 1:
                time.sleep(2 ** i)  # Exponential backoff
            else:
                raise

text = "Your text here"
embeddings = get_embeddings_with_retries(text)
# Custom respond function
def respond(query_str: str):
    QA_PROMPT_TMPL = (
        "Context information is below. \n"
        "---------------------\n"
        "{context_str}"
        "\n---------------------\n"
        "Given this information, answer from context, be polite and generate short and clear responses. Please answer the question: {query_str}\n"
    )

    response = index.query(query_str, text_qa_template=QA_PROMPT_TMPL)
    return response

# Webhook route
@app.route("/", methods=["GET", "POST"])
def hook():
    if request.method == "GET":
        if request.args.get("hub.verify_token") == VERIFY_TOKEN:
            logging.info("Verified webhook")
            response = make_response(request.args.get("hub.challenge"), 200)
            response.mimetype = "text/plain"
            return response
        logging.error("Webhook Verification failed")
        return "Invalid verification token"

    # Get message update.. we want only to work with text only
    data = request.get_json()
    logging.info("Received data: %s", data)
    changed_field = messenger.changed_field(data)
    
    if changed_field == "messages":
        new_message = messenger.get_mobile(data)
        if new_message:
            mobile = messenger.get_mobile(data)
            message_type = messenger.get_message_type(data)

            if message_type == "text":
                message = messenger.get_message(data)
                response = respond(message)
                logging.info("\nResponse: %s\n", response)
                messenger.send_message(message=f"{response}", recipient_id=mobile)
            else:
                messenger.send_message(message="Please send me text messages", recipient_id=mobile)
                
    return "ok"
print("----------end----------")
if __name__ == "__main__":
    app.run(port=5000, debug=True)
